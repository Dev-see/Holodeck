const TYPE_COLORS = {
  Fire: 'var(--fire)', Grass: 'var(--grass)', Water: 'var(--water)', Psychic: 'var(--psychic)',
  Lightning: 'var(--lightning)', Fighting: 'var(--fighting)', Colorless: '#c9d4cf',
  Darkness: '#8b7ad1', Metal: '#a8b6c2', Dragon: '#e0a94a', Fairy: '#f3a8d1'
};

function compRow(label, val, max, color) {
  const pct = Math.round((val / max) * 100);
  return (
    <div className="comp-row" key={label}>
      <div className="comp-label">{label}</div>
      <div className="comp-track"><div className="comp-fill" style={{ width: pct + '%', background: color }} /></div>
      <div className="comp-num hf-mono">{val}</div>
    </div>
  );
}

export default function AnalysisPanel({ deck, pool, onRefine, onExport, refineText, setRefineText }) {
  if (!deck) {
    return (
      <aside className="analysis-panel hf-panel">
        <div className="eyebrow">Deck Analyst</div>
        <p style={{ fontSize: '13px', color: 'var(--muted-2)', lineHeight: 1.6 }}>
          Forge a deck to see composition breakdowns, strategy notes, and matchup reads here.
        </p>
      </aside>
    );
  }

  const pokemonCount = deck.cards.filter(c => c.category === 'Pokemon').reduce((a, c) => a + c.count, 0);
  const trainerCount = deck.cards.filter(c => c.category === 'Trainer').reduce((a, c) => a + c.count, 0);
  const energyCount = deck.cards.filter(c => c.category === 'Energy').reduce((a, c) => a + c.count, 0);
  const maxCat = Math.max(pokemonCount, trainerCount, energyCount, 1);

  const energyTypeMap = {};
  deck.cards.filter(c => c.category === 'Energy').forEach(entry => {
    const card = pool.get(entry.id);
    if (!card) return;
    const t = (card.types && card.types[0]) || card.name.replace(' Energy', '');
    energyTypeMap[t] = (energyTypeMap[t] || 0) + entry.count;
  });
  const energyEntries = Object.entries(energyTypeMap);
  const energyTotal = energyEntries.reduce((a, [, v]) => a + v, 0) || 1;

  return (
    <aside className="analysis-panel hf-panel">
      <div className="eyebrow">Deck Analyst</div>

      <div className="section-block">
        <h3>Composition</h3>
        <div className="comp-bars">
          {compRow('Pokémon', pokemonCount, maxCat, 'var(--holo-a)')}
          {compRow('Trainer', trainerCount, maxCat, 'var(--holo-b)')}
          {compRow('Energy', energyCount, maxCat, 'var(--holo-c)')}
        </div>
      </div>

      {energyEntries.length > 0 && (
        <div className="section-block">
          <h3>Energy Mix</h3>
          <div className="energy-legend">
            {energyEntries.map(([t, v]) => (
              <div className="row" key={t}>
                <span className="swatch" style={{ background: TYPE_COLORS[t] || '#8fa39a' }} />
                {t} · {v} ({Math.round(v / energyTotal * 100)}%)
              </div>
            ))}
          </div>
        </div>
      )}

      {deck.strategyNotes?.length > 0 && (
        <div className="section-block">
          <h3>Strategy</h3>
          <div className="note-list">
            {deck.strategyNotes.map((n, i) => <div className="note-item" key={i}>{n}</div>)}
          </div>
        </div>
      )}

      {deck.debug && (
        <div className="section-block">
          <h3>Build Debug</h3>
          <div className="note-list">
            <div className="note-item">Score: {deck.debug.score ?? 'n/a'}</div>
            <div className="note-item">Main attacker: {deck.debug.mainCard || 'n/a'}</div>
            <div className="note-item">Primary type: {deck.debug.primaryType || 'n/a'}</div>
            <div className="note-item">Pool size: {deck.debug.poolSize ?? 'n/a'}</div>
          </div>
        </div>
      )}

      {deck.techNotes?.length > 0 && (
        <div className="section-block">
          <h3>Tech Choices</h3>
          <div className="note-list">
            {deck.techNotes.map((n, i) => <div className="note-item" key={i}>{n}</div>)}
          </div>
        </div>
      )}

      {deck.matchupNotes?.length > 0 && (
        <div className="section-block">
          <h3>Matchups</h3>
          <div className="note-list">
            {deck.matchupNotes.map((n, i) => <div className="note-item" key={i}>{n}</div>)}
          </div>
        </div>
      )}

      <div className="section-block">
        <h3>Refine</h3>
        <div className="refine-box">
          <textarea
            value={refineText}
            onChange={(e) => setRefineText(e.target.value)}
            placeholder="e.g. swap in more disruption, cut the tech card, lower the curve..."
          />
          <button className="btn-forge" style={{ marginTop: '10px' }} onClick={onRefine}>Refine Deck</button>
        </div>
        <button className="btn-ghost" onClick={onExport}>Export Decklist</button>
      </div>
    </aside>
  );
}