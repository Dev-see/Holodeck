function cardImgUrl(card, size) {
  if (!card || !card.images) return '';
  return size === 'large' ? (card.images.large || card.images.small) : (card.images.small || card.images.large);
}

export default function CardModal({ card, onClose }) {
  if (!card) return null;
  const typesRow = (card.types || []).map(t => <span className="pill" key={t}>{t}</span>);
  const legalRow = ['standard', 'expanded', 'unlimited'].map(f => {
    const status = card.legalities && card.legalities[f];
    return status === 'Legal' ? <span className="pill" key={f} style={{ color: 'var(--holo-a)', borderColor: 'var(--holo-a)' }}>{f}</span> : null;
  });
  const attacksText = (card.attacks || []).map(a => `${a.name} — ${(a.cost || []).join('')} — ${a.damage || ''}\n${a.text || ''}`).join('\n\n');
  const abilitiesText = (card.abilities || []).map(a => `[${a.type}] ${a.name}\n${a.text || ''}`).join('\n\n');
  const rulesText = (card.rules || []).join('\n');
  const fullText = [abilitiesText, attacksText, rulesText].filter(Boolean).join('\n\n');

  return (
    <div className="hf-modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="hf-modal-inner" style={{ display: 'flex', gap: '28px', maxWidth: '820px' }}>
        <button className="hf-modal-close" onClick={onClose}>✕</button>
        <img src={cardImgUrl(card, 'large')} alt={card.name} style={{ width: '260px', borderRadius: '12px', flexShrink: 0 }} />
        <div className="modal-details" style={{ flex: 1 }}>
          <h3 style={{ fontSize: '22px', textTransform: 'uppercase' }}>{card.name}</h3>
          <div className="type-row" style={{ margin: '10px 0', display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            {typesRow}
            {card.hp && <span className="pill">HP {card.hp}</span>}
          </div>
          <div className="rule-text" style={{ fontSize: '13px', lineHeight: 1.6, color: 'var(--muted)', marginTop: '12px', whiteSpace: 'pre-wrap' }}>
            {fullText}
          </div>
          <div className="legal-row" style={{ display: 'flex', gap: '8px', marginTop: '14px' }}>
            {legalRow}
          </div>
        </div>
      </div>
    </div>
  );
}