import { useEffect, useRef } from 'react';

const QUICK_CHIPS = [
  { label: 'Meta netdeck', fill: 'Build the strongest current standard meta deck for this archetype: ' },
  { label: 'Off-meta rogue', fill: 'Build an off-meta rogue deck that can beat top standard decks by surprise: ' },
  { label: 'New release spotlight', fill: 'Build a deck that showcases the newest legal set, using its standout new cards: ' },
  { label: 'Mill / control', fill: 'Build a mill/deck-out control deck: ' },
];

export default function ControlPanel({ request, setRequest, onForge, onSurprise, forging, statusLines, debugLines, progress, error, onRetry }) {
  const debugRef = useRef(null);
  const statusRef = useRef(null);

  useEffect(() => { if (debugRef.current) debugRef.current.scrollTop = debugRef.current.scrollHeight; }, [debugLines]);
  useEffect(() => { if (statusRef.current) statusRef.current.scrollTop = statusRef.current.scrollHeight; }, [statusLines]);

  const fmtTime = (d) => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const fmtDebugTime = (d) => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', fractionalSecondDigits: 1 });

  return (
    <aside className="control-panel hf-panel">
      <div className="eyebrow">Deck Request</div>
      <textarea
        className="hf-textarea"
        value={request}
        onChange={(e) => setRequest(e.target.value)}
        placeholder="e.g. Build a Charizard ex standard deck around the newest set. Or: give me a rogue expanded idea nobody plays."
      />
      <div className="chips">
        {QUICK_CHIPS.map(chip => (
          <div key={chip.label} className="chip" onClick={() => { setRequest(chip.fill); }}>
            {chip.label}
          </div>
        ))}
      </div>
      <button className="btn-forge" onClick={onForge} disabled={forging}>Forge Deck</button>
      <button className="btn-ghost" onClick={onSurprise} disabled={forging}>Surprise me with an archetype</button>

      <div className="status-log" ref={statusRef}>
        {statusLines.length === 0 && <div style={{ fontSize: '11px', color: 'var(--muted-2)', padding: '4px' }}>Waiting for a forge run…</div>}
        {statusLines.map((line, i) => (
          <div key={i} className={`status-line ${line.active ? 'active' : 'done'}`}>
            <span className="dot" />
            <span className="status-time">{fmtTime(line.time)}</span>
            <span className="status-detail">{line.text}{line.detail ? ' — ' + line.detail : ''}</span>
          </div>
        ))}
      </div>

      <div className="forge-progress">
        <div className="forge-progress-head">
          <span>{progress?.label || 'Idle'}</span>
          <span>{Math.round(progress?.pct || 0)}%</span>
        </div>
        <div className="forge-progress-track">
          <div className="forge-progress-fill" style={{ width: `${progress?.pct || 0}%` }} />
        </div>
        <div className="forge-progress-meta">{progress?.meta || 'Waiting for a forge run…'}</div>
      </div>

      <div className="eyebrow" style={{ marginTop: '18px' }}>Live Trace</div>
      <div className="live-debug" ref={debugRef}>
        {debugLines.length === 0 ? 'Waiting for Forge Deck…' : debugLines.map((line, i) => (
          <div key={i} className="dbg-line">
            <span className="dbg-time">[{fmtDebugTime(line.time)}]</span> <span className="dbg-kind">{line.kind}</span> {line.text}
          </div>
        ))}
      </div>

      {error && (
        <div className="error-box">
          {error}
          {onRetry && <button className="btn-ghost" style={{ marginTop: '8px' }} onClick={onRetry}>Try again</button>}
        </div>
      )}
    </aside>
  );
}