import { Sparkles } from 'lucide-react';

const TABS = [
  { id: 'all', label: 'All' },
  { id: 'Pokemon', label: 'Pokémon' },
  { id: 'Trainer', label: 'Trainer' },
  { id: 'Energy', label: 'Energy' },
];

function cardImgUrl(card, size) {
  if (!card || !card.images) return '';
  return size === 'large' ? (card.images.large || card.images.small) : (card.images.small || card.images.large);
}

export default function DeckView({ deck, pool, activeTab, setActiveTab, onCardClick }) {
  if (!deck) {
    return (
      <main className="deck-view">
        <div className="empty-state">
          <div className="glyph"><Sparkles size={28} /></div>
          <h2>No deck forged yet</h2>
          <p>Describe an archetype, a strategy, or just a vibe. Holoforge pulls live card data from the Pokémon TCG database and drafts a full 60-card list built for the format you pick.</p>
        </div>
      </main>
    );
  }

  const total = deck.cards.reduce((a, c) => a + c.count, 0);
  const pokemonCount = deck.cards.filter(c => c.category === 'Pokemon').reduce((a, c) => a + c.count, 0);
  const trainerCount = deck.cards.filter(c => c.category === 'Trainer').reduce((a, c) => a + c.count, 0);
  const energyCount = deck.cards.filter(c => c.category === 'Energy').reduce((a, c) => a + c.count, 0);
  const filtered = deck.cards.filter(c => activeTab === 'all' || c.category === activeTab);

  return (
    <main className="deck-view">
      <div className="deck-header">
        <h2 className="holo-text">{deck.deckName || 'Untitled Deck'}</h2>
        <div className="summary" style={{ color: '#e4eee9' }}>{deck.archetypeSummary || ''}</div>
        <div className="deck-meta-row">
          <div className={`pill ${total !== 60 ? 'warn' : ''}`}>{total} / 60 cards</div>
          <div className="pill">{pokemonCount} Pokémon · {trainerCount} Trainer · {energyCount} Energy</div>
        </div>
      </div>

      <div className="tabs">
        {TABS.map(tab => (
          <div key={tab.id} className={`tab ${activeTab === tab.id ? 'active' : ''}`} onClick={() => setActiveTab(tab.id)}>
            {tab.label}
          </div>
        ))}
      </div>

      <div className="card-grid">
        {filtered.map(entry => {
          const card = pool.get(entry.id);
          if (!card) return null;
          return (
            <div key={entry.id} className="tcg-card" onClick={() => onCardClick(card)}>
              <img src={cardImgUrl(card, 'small')} alt={card.name} loading="lazy" />
              <div className="holo-sweep" />
              <div className="count-badge">×{entry.count}</div>
              <div className="card-label">
                <div className="name">{card.name}</div>
                <div className="sub hf-mono">{card.set?.name || ''}</div>
              </div>
            </div>
          );
        })}
      </div>
    </main>
  );
}