export default function ExportModal({ deck, pool, onClose }) {
  if (!deck) return null;

  const groups = { Pokemon: [], Trainer: [], Energy: [] };
  deck.cards.forEach(entry => {
    const card = pool.get(entry.id);
    if (!card) return;
    (groups[entry.category] || groups.Trainer).push({ card, count: entry.count });
  });

  const block = (title, items) => {
    const count = items.reduce((a, i) => a + i.count, 0);
    const lines = items.map(i => {
      const code = (i.card.set && (i.card.set.ptcgoCode || i.card.set.id.toUpperCase())) || '';
      return `${i.count} ${i.card.name} ${code} ${i.card.number || ''}`.trim();
    });
    return `${title}: ${count}\n${lines.join('\n')}`;
  };

  const text = [
    block('Pokémon', groups.Pokemon),
    block('Trainer', groups.Trainer),
    block('Energy', groups.Energy),
    `Total Cards: ${deck.cards.reduce((a, c) => a + c.count, 0)}`
  ].join('\n\n');

  const copy = () => {
    navigator.clipboard?.writeText(text).catch(() => {});
  };

  return (
    <div className="hf-modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="hf-modal-inner">
        <button className="hf-modal-close" onClick={onClose}>✕</button>
        <h3 style={{ marginBottom: '14px', textTransform: 'uppercase' }}>Export Decklist</h3>
        <textarea
          readOnly
          value={text}
          style={{ width: '100%', height: '340px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text)', fontFamily: "'JetBrains Mono', monospace", fontSize: '12px', padding: '14px', resize: 'none', outline: 'none', lineHeight: 1.6 }}
        />
        <button className="btn-forge" style={{ marginTop: '14px' }} onClick={copy}>Copy to Clipboard</button>
      </div>
    </div>
  );
}