import { useState, useEffect, useRef } from 'react';
import { loadHoloBackdropArt } from '@/lib/tcgApi';

export default function HoloBackdrop() {
  const [art, setArt] = useState(null);
  const timerRef = useRef(null);

  const load = async () => {
    const result = await loadHoloBackdropArt();
    if (result) setArt(result);
  };

  useEffect(() => {
    load();
    const refresh = () => { if (document.visibilityState === 'visible') load(); };
    const interval = setInterval(refresh, 60000);
    document.addEventListener('visibilitychange', refresh);
    return () => { clearInterval(interval); document.removeEventListener('visibilitychange', refresh); };
  }, []);

  const bgStyle = art
    ? {
        backgroundImage: `
          radial-gradient(circle at 20% 20%, rgba(192,132,252,0.30), transparent 34%),
          radial-gradient(circle at 80% 8%, rgba(94,234,212,0.24), transparent 30%),
          radial-gradient(circle at 50% 92%, rgba(244,114,182,0.20), transparent 38%),
          linear-gradient(180deg, rgba(7,11,9,0.12), rgba(7,11,9,0.84)),
          url("${art.url}")
        `,
        backgroundSize: 'cover, cover, cover, cover, min(58vmax, 900px) auto',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        filter: 'saturate(1.12) contrast(1.08) brightness(0.86)',
        opacity: 1,
      }
    : {
        backgroundImage: `
          radial-gradient(circle at 15% 18%, rgba(94,234,212,0.18), transparent 34%),
          radial-gradient(circle at 82% 12%, rgba(192,132,252,0.20), transparent 30%),
          radial-gradient(circle at 48% 88%, rgba(244,114,182,0.14), transparent 38%),
          linear-gradient(180deg, rgba(7,11,9,0.18), rgba(7,11,9,0.86))
        `,
      };

  return <div className="hf-holo-backdrop" style={bgStyle} aria-hidden="true" title={art ? `${art.name} — ${art.rarity || 'Pokémon foil'}` : ''} />;
}