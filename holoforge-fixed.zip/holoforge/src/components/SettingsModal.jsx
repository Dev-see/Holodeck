import { useState } from 'react';
import { getDataSettings, saveDataSettings, testDataConnection } from '@/lib/tcgApi';
import { getAiSettings, saveAiSettings, testAiConnection, getProviderDefaults } from '@/lib/aiProvider';

export default function SettingsModal({ onClose }) {
  const current = getDataSettings();
  const [baseUrl, setBaseUrl] = useState(current.baseUrl);
  const [proxy, setProxy] = useState(current.proxy);
  const [apiKey, setApiKey] = useState(current.apiKey);
  const [status, setStatus] = useState(null); // { ok: boolean, text: string }

  const currentAi = getAiSettings();
  const [aiProvider, setAiProvider] = useState(currentAi.provider || 'groq');
  const [aiApiKey, setAiApiKey] = useState(currentAi.apiKey || '');
  const [aiModel, setAiModel] = useState(currentAi.model || '');
  const [aiBaseUrl, setAiBaseUrl] = useState(currentAi.baseUrl || '');
  const [aiStatus, setAiStatus] = useState(null);

  const aiDefaults = getProviderDefaults(aiProvider);

  const handleTest = async () => {
    setStatus({ ok: null, text: 'Testing…' });
    saveDataSettings({ baseUrl: baseUrl.trim() || 'https://api.pokemontcg.io/v2', proxy: proxy.trim(), apiKey: apiKey.trim() });
    try {
      const msg = await testDataConnection();
      setStatus({ ok: true, text: msg });
    } catch (e) {
      setStatus({ ok: false, text: e.message || 'Connection failed.' });
    }
  };

  const handleSave = () => {
    saveDataSettings({ baseUrl: baseUrl.trim() || 'https://api.pokemontcg.io/v2', proxy: proxy.trim(), apiKey: apiKey.trim() });
    setStatus({ ok: true, text: 'Saved.' });
  };

  const handleAiSave = () => {
    saveAiSettings({ provider: aiProvider, apiKey: aiApiKey.trim(), model: aiModel.trim(), baseUrl: aiBaseUrl.trim() });
    setAiStatus({ ok: true, text: 'Saved.' });
  };

  const handleAiTest = async () => {
    setAiStatus({ ok: null, text: 'Testing…' });
    saveAiSettings({ provider: aiProvider, apiKey: aiApiKey.trim(), model: aiModel.trim(), baseUrl: aiBaseUrl.trim() });
    const result = await testAiConnection();
    setAiStatus(result);
  };

  return (
    <div className="hf-modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="hf-modal-inner">
        <button className="hf-modal-close" onClick={onClose}>✕</button>
        <h3 style={{ marginBottom: '6px', textTransform: 'uppercase' }}>Card Data Source</h3>
        <p style={{ fontSize: '12.5px', color: 'var(--muted-2)', lineHeight: 1.6, marginBottom: '18px' }}>
          If card pulls keep failing, your browser or network may be blocking direct requests to the Pokémon TCG API. Point Holoforge at a CORS proxy or a different mirror below.
        </p>
        <div className="settings-field">
          <label>API Base URL</label>
          <input value={baseUrl} onChange={(e) => setBaseUrl(e.target.value)} placeholder="https://api.pokemontcg.io/v2" />
          <div className="hint">Where card and set data is fetched from.</div>
        </div>
        <div className="settings-field">
          <label>CORS Proxy Prefix (optional)</label>
          <input value={proxy} onChange={(e) => setProxy(e.target.value)} placeholder="e.g. https://corsproxy.io/?url=" />
          <div className="hint">Prepended to the request URL if direct calls are blocked. Leave blank to call the API directly.</div>
        </div>
        <div className="settings-field">
          <label>API Key (optional)</label>
          <input value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="pokemontcg.io API key" />
          <div className="hint">Raises your rate limit. Sent as an X-Api-Key header. Not required.</div>
        </div>
        <button className="btn-forge" onClick={handleTest}>Test Connection</button>
        <button className="btn-ghost" style={{ marginTop: '8px' }} onClick={handleSave}>Save</button>
        {status && (
          <div style={{ fontSize: '12.5px', marginTop: '12px', minHeight: '18px' }} className={status.ok === true ? 'hf-status-ok' : status.ok === false ? 'hf-status-bad' : ''}>
            {status.text}
          </div>
        )}

        <div style={{ height: '1px', background: 'var(--border)', margin: '22px 0' }} />

        <h3 style={{ marginBottom: '6px', textTransform: 'uppercase' }}>AI Model Provider</h3>
        <p style={{ fontSize: '12.5px', color: 'var(--muted-2)', lineHeight: 1.6, marginBottom: '18px' }}>
          Optional. Configure a provider to have an AI propose the archetype and key cards before the local engine builds and scores the 60-card deck. Without a key, Holoforge still forges decks using the local engine alone.
        </p>
        <div className="settings-field">
          <label>Provider</label>
          <select
            value={aiProvider}
            onChange={(e) => setAiProvider(e.target.value)}
            style={{ width: '100%', background: 'var(--surface-2)', border: '1px solid var(--border)', color: 'var(--text)', padding: '10px 12px', borderRadius: '8px', fontSize: '13px', outline: 'none', fontFamily: "'JetBrains Mono', monospace" }}
          >
            <option value="anthropic">Anthropic (Claude)</option>
            <option value="groq">Groq</option>
            <option value="custom">Custom (OpenAI-compatible)</option>
          </select>
        </div>
        <div className="settings-field">
          <label>API Key</label>
          <input value={aiApiKey} onChange={(e) => setAiApiKey(e.target.value)} placeholder={aiProvider === 'anthropic' ? 'sk-ant-...' : aiProvider === 'groq' ? 'gsk_...' : 'your API key'} />
          <div className="hint">Stored locally in your browser, sent directly to the provider. Never sent anywhere else.</div>
        </div>
        <div className="settings-field">
          <label>Model</label>
          <input value={aiModel} onChange={(e) => setAiModel(e.target.value)} placeholder={aiDefaults.model || 'model name'} />
        </div>
        {aiProvider === 'custom' && (
          <div className="settings-field">
            <label>Base URL</label>
            <input value={aiBaseUrl} onChange={(e) => setAiBaseUrl(e.target.value)} placeholder="https://.../chat/completions" />
            <div className="hint">Any OpenAI-compatible chat-completions endpoint.</div>
          </div>
        )}
        <button className="btn-forge" onClick={handleAiTest}>Test Connection</button>
        <button className="btn-ghost" style={{ marginTop: '8px' }} onClick={handleAiSave}>Save</button>
        {aiStatus && (
          <div style={{ fontSize: '12.5px', marginTop: '12px', minHeight: '18px' }} className={aiStatus.ok === true ? 'hf-status-ok' : aiStatus.ok === false ? 'hf-status-bad' : ''}>
            {aiStatus.text}
          </div>
        )}
      </div>
    </div>
  );
}
