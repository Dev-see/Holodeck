import { useState, useEffect, useRef } from 'react';

const ORB_COLORS = ['#5eead4', '#c084fc', '#f472b6', '#5ec8f2', '#f5d547'];

export default function SplashScreen({ onEnter }) {
  const [hidden, setHidden] = useState(false);
  const fieldRef = useRef(null);

  useEffect(() => {
    const field = fieldRef.current;
    if (!field) return;
    for (let i = 0; i < 22; i++) {
      const o = document.createElement('div');
      o.className = 'orb';
      const ang = Math.random() * Math.PI * 2;
      const dist = 120 + Math.random() * 90;
      o.style.setProperty('--tx', Math.cos(ang) * dist + 'px');
      o.style.setProperty('--ty', Math.sin(ang) * dist + 'px');
      o.style.background = ORB_COLORS[i % ORB_COLORS.length];
      o.style.left = 'calc(50% - 7px)';
      o.style.top = 'calc(50% - 7px)';
      o.style.animationDelay = Math.random() * 0.5 + 's';
      field.appendChild(o);
    }
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const timer = setTimeout(enter, reduced ? 800 : 4200);
    return () => clearTimeout(timer);
  }, []);

  const enter = () => {
    setHidden(true);
    setTimeout(() => onEnter(), 700);
  };

  return (
    <div className={`hf-splash ${hidden ? 'hide' : ''}`} onClick={enter}>
      <div className="splash-orb-field" ref={fieldRef} />
      <div className="splash-mark">
        <div className="splash-title holo-text">HOLOFORGE</div>
        <div className="splash-sub">AI Deck Architect · Standard & Expanded</div>
      </div>
      <div className="splash-hint">CLICK TO ENTER</div>
    </div>
  );
}