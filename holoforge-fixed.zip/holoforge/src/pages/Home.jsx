import { useState, useEffect, useRef } from 'react';
import SplashScreen from '@/components/SplashScreen';
import ParticleField from '@/components/ParticleField';
import HoloBackdrop from '@/components/HoloBackdrop';
import ControlPanel from '@/components/ControlPanel';
import DeckView from '@/components/DeckView';
import AnalysisPanel from '@/components/AnalysisPanel';
import CardModal from '@/components/CardModal';
import ExportModal from '@/components/ExportModal';
import SettingsModal from '@/components/SettingsModal';
import { onDebug, onStatus, onProgress, emitDebug, emitStatus, emitProgress, fetchLegalCardPool, fetchQueryBatch } from '@/lib/tcgApi';
import { planSearchQueries, buildDeckAI, compactCard } from '@/lib/deckEngine';
import { callAI, extractJSON, isAiConfigured, getAiSettings } from '@/lib/aiProvider';

const SURPRISES = [
  'Build a rogue deck around a Stage 2 line nobody is playing right now.',
  "Build a mono-type deck that hasn't seen top-cut play recently.",
  'Build an aggressive one-prize deck that punishes ex/EX decks.',
  'Build a toolbox deck using Ability-based engines.',
  'Build a deck around the flashiest new Pokémon from the latest set.'
];

export default function Home() {
  const [splashVisible, setSplashVisible] = useState(true);
  const [format, setFormat] = useState('standard');
  const [request, setRequest] = useState('');
  const [refineText, setRefineText] = useState('');
  const [currentDeck, setCurrentDeck] = useState(null);
  const [activeTab, setActiveTab] = useState('all');
  const [selectedCard, setSelectedCard] = useState(null);
  const [showExport, setShowExport] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [forging, setForging] = useState(false);
  const [statusLines, setStatusLines] = useState([]);
  const [debugLines, setDebugLines] = useState([]);
  const [progress, setProgress] = useState({ pct: 0, label: 'Idle', meta: 'Waiting for a forge run…' });
  const [error, setError] = useState(null);
  const pool = useRef(new Map());
  const lastForgeCall = useRef(null);

  useEffect(() => {
    const off1 = onDebug((kind, text) => setDebugLines(prev => [...prev, { kind, text, time: new Date() }]));
    const off2 = onStatus((text, detail) => setStatusLines(prev => [...prev.map(l => ({ ...l, active: false })), { text, detail, time: new Date(), active: true }]));
    const off3 = onProgress((pct, label, meta) => setProgress({ pct, label, meta }));
    return () => { off1(); off2(); off3(); };
  }, []);

  const mergeIntoPool = (cards) => { cards.forEach(c => { if (!pool.current.has(c.id)) pool.current.set(c.id, c); }); };
  const legalPoolArray = () => Array.from(pool.current.values()).filter(c => !c.legalities || c.legalities[format] === 'Legal');
  const clearStatus = () => { setStatusLines([]); setDebugLines([]); };
  const resetForgeProgress = () => setProgress({ pct: 0, label: 'Starting', meta: 'Preparing request…' });
  const finishStatus = () => setStatusLines(prev => prev.map(l => ({ ...l, active: false })));

  const runForge = async (requestText, refinement) => {
    lastForgeCall.current = () => runForge(requestText, refinement);
    setError(null);
    clearStatus();
    resetForgeProgress();
    emitDebug('TRACE', 'Request received: ' + requestText);
    emitDebug('TRACE', refinement ? 'Refinement: ' + refinement : 'No refinement yet.');
    setForging(true);

    try {
      emitStatus('Step 1/5 — loading the full legal card pool...', 'Starting paginated legal-card retrieval; cached pages will return immediately.');
      emitDebug('TRACE', `Format: ${format.toUpperCase()}`);
      const existingLegal = legalPoolArray();
      let legalPool;
      if (existingLegal.length >= 1000) {
        legalPool = existingLegal;
        emitStatus(`Reusing ${legalPool.length} legal cards already loaded — skipping database fetch.`, 'Your previous fetch is still available in memory.');
        emitDebug('TRACE', `Reusing existing legal pool: ${legalPool.length} cards`);
      } else {
        legalPool = await fetchLegalCardPool(format, (info) => {
          emitDebug('TRACE', `Legal pool page ${info.page}/${info.totalPages}: ${info.completed}${info.totalCount ? ' / ' + info.totalCount : ''} cards${info.cached ? ' · loaded from cache' : ''}`);
        });
        mergeIntoPool(legalPool);
      }
      emitStatus('Loaded ' + legalPool.length + ' legal cards into the working pool.', 'Deduplicating and preparing the search universe.');
      finishStatus();

      emitProgress(100, 'Legal pool complete', `Loaded ${legalPool.length} legal cards · moving to request analysis`);
      emitStatus('Step 2/5 — planning a compact search plan...', 'Reading your request for Pokémon, type, strategy, conditions, acceleration, draw, and control signals.');
      const plan = planSearchQueries(requestText, format);
      finishStatus();
      const planQueries = plan.searchQueries || [];
      emitDebug('TRACE', 'Step 2/5: search planner finished');
      emitDebug('TRACE', 'Planner note: ' + (plan.note || 'No note returned.'));
      emitDebug('TRACE', 'Search queries: ' + (planQueries.length ? planQueries.join(' | ') : 'none'));

      if (planQueries.length) {
        emitProgress(0, 'Request-specific search', `0/${planQueries.length} planned queries completed`);
        emitStatus('Step 3/5 — fetching request-specific cards in batches...', 'Searching only for cards that can improve the requested strategy.');
        const results = await fetchQueryBatch(planQueries, 40, 3, (done, total, queryCount, queryLabel, resultCount) => {
          const pct = Math.round((done / Math.max(total, 1)) * 100);
          emitProgress(pct, `Request search · batch ${done}/${total}`, `${resultCount} cards accumulated · ${queryLabel}`);
          emitStatus(`Step 3/5 — batch ${done}/${total} complete`, `${pct}% · ${queryCount} quer${queryCount === 1 ? 'y' : 'ies'} · ${resultCount} cards accumulated`);
        });
        mergeIntoPool(results);
        emitStatus('Fetched ' + results.length + ' request-specific cards.');
        finishStatus();
      } else {
        emitStatus('Step 3/5 — no search plan was returned, using the legal pool cache only.');
        finishStatus();
      }

      emitProgress(100, 'Card search complete', `Working pool: ${legalPoolArray().length} cards · starting archetype planning`);

      let aiPlan = null;
      if (isAiConfigured()) {
        const providerName = getAiSettings().provider;
        emitStatus(`Step 4/5 — asking ${providerName} to plan an archetype...`, 'Sending your request plus a compact card sample to the configured AI provider.');
        try {
          const sample = legalPoolArray().filter(c => c.supertype !== 'Energy').slice(0, 60).map(compactCard);
          const prompt = `You are helping build a Pokemon TCG ${format} deck. User request: "${requestText}"${refinement ? `\nRefinement: "${refinement}"` : ''}\n\nHere is a sample of legal cards you can consider (JSON, truncated):\n${JSON.stringify(sample)}\n\nReply with ONLY a JSON object, no prose, no markdown fences, in this exact shape:\n{"mainCard":"<best anchor Pokémon name>","type":"<Fire|Water|Grass|Lightning|Psychic|Fighting|Darkness|Metal|Colorless>","archetype":"<short archetype name>","strategy":"<1-2 sentence gameplan>","keyCards":["<supporting card name>", "..."]}`;
          const reply = await callAI([{ role: 'user', content: prompt }]);
          aiPlan = extractJSON(reply);
          emitDebug('TRACE', 'AI plan: ' + JSON.stringify(aiPlan));
          emitStatus(`AI proposed: ${aiPlan.archetype || aiPlan.mainCard || 'a plan'}.`, aiPlan.strategy || '');
        } catch (aiErr) {
          emitDebug('TRACE', 'AI planning skipped: ' + (aiErr.message || String(aiErr)));
          emitStatus('AI planning unavailable — continuing with the local engine only.', aiErr.message || String(aiErr));
        }
        finishStatus();
      } else {
        emitDebug('TRACE', 'No AI provider configured — using the local engine only. Configure one in Settings to enable AI-assisted planning.');
      }

      const augmentedRequest = aiPlan
        ? `${requestText}\nAI-assisted plan: build around ${aiPlan.mainCard || 'the strongest attacker'}${aiPlan.type ? ` (${aiPlan.type} type)` : ''}. ${aiPlan.archetype ? `Archetype: ${aiPlan.archetype}.` : ''} ${aiPlan.strategy || ''} ${Array.isArray(aiPlan.keyCards) && aiPlan.keyCards.length ? `Key support cards: ${aiPlan.keyCards.join(', ')}.` : ''}`
        : requestText;

      emitStatus('Step 5/5 — running local deck simulation and scoring candidates...', 'Testing speed, consistency, attacker readiness, energy flow, draw, search, and interaction.');
      emitProgress(15, 'Local deck simulation', 'Generating and scoring candidate deck variants…');
      const result = buildDeckAI(augmentedRequest, format, legalPoolArray(), refinement);
      finishStatus();

      if (result.status !== 'final') throw new Error('Deck simulation could not finalize a deck. Try rephrasing your request.');

      if (aiPlan?.strategy) result.strategyNotes = [aiPlan.strategy, ...(result.strategyNotes || [])];

      emitProgress(100, 'Forge complete', `Selected ${result.deckName || 'deck'} · 60-card result`);
      setCurrentDeck(result);
      setActiveTab('all');
      emitDebug('TRACE', 'Deck finalized: ' + (result.deckName || 'Untitled Deck'));
      emitDebug('TRACE', 'Main attacker: ' + (result.debug?.mainCard || 'unknown'));
      emitDebug('TRACE', 'Score: ' + (result.debug?.score || 0));
    } catch (err) {
      setError(err.message || String(err));
      emitDebug('TRACE', 'Error: ' + (err.message || String(err)));
    } finally {
      setForging(false);
    }
  };

  const handleForge = () => {
    if (!request.trim()) { setError('Describe what kind of deck you want first.'); return; }
    setCurrentDeck(null);
    runForge(request.trim());
  };

  const handleSurprise = () => {
    const pick = SURPRISES[Math.floor(Math.random() * SURPRISES.length)];
    setRequest(pick);
    setCurrentDeck(null);
    runForge(pick);
  };

  const handleRefine = () => {
    if (!refineText.trim()) return;
    runForge(request.trim() || 'refine deck', refineText.trim());
  };

  if (splashVisible) {
    return <SplashScreen onEnter={() => setSplashVisible(false)} />;
  }

  return (
    <div className="hf-root">
      <ParticleField />
      <HoloBackdrop />
      <div className="hf-app">
        <header className="hf-header">
          <div className="hf-brand">
            <div className="brand-mark" />
            <div>
              <div className="brand-name">Holoforge</div>
              <div className="brand-tag">Live TCG Database · AI Deck Architect</div>
            </div>
          </div>
          <div className="format-toggle">
            <button className={format === 'standard' ? 'active' : ''} onClick={() => setFormat('standard')}>Standard</button>
            <button className={format === 'expanded' ? 'active' : ''} onClick={() => setFormat('expanded')}>Expanded</button>
          </div>
          <button
            onClick={() => setShowSettings(true)}
            title="Data source settings"
            style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', color: 'var(--muted-2)', width: '36px', height: '36px', borderRadius: '9px', cursor: 'pointer', fontSize: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginLeft: '10px', flexShrink: 0 }}
          >⚙</button>
        </header>
        <div className="hf-layout">
          <ControlPanel
            request={request}
            setRequest={setRequest}
            onForge={handleForge}
            onSurprise={handleSurprise}
            forging={forging}
            statusLines={statusLines}
            debugLines={debugLines}
            progress={progress}
            error={error}
            onRetry={lastForgeCall.current}
          />
          <DeckView
            deck={currentDeck}
            pool={pool.current}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onCardClick={setSelectedCard}
          />
          <AnalysisPanel
            deck={currentDeck}
            pool={pool.current}
            onRefine={handleRefine}
            onExport={() => setShowExport(true)}
            refineText={refineText}
            setRefineText={setRefineText}
          />
        </div>
      </div>
      <CardModal card={selectedCard} onClose={() => setSelectedCard(null)} />
      {showExport && <ExportModal deck={currentDeck} pool={pool.current} onClose={() => setShowExport(false)} />}
      {showSettings && <SettingsModal onClose={() => setShowSettings(false)} />}
    </div>
  );
}